package com.example.brandonscahill.appproject2;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button btnNews;
    private Button btnHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    //Assign a variable to the News Button
        btnNews = (Button) findViewById(R.id.btnNews);
        btnNews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity2();
            }
        });
        btnHistory = (Button) findViewById(R.id.btnHistory);
        btnHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity3();
            }
        });
    }
    //Starts The News Activity
    public void openActivity2() {
     Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.reddit.com/r/CryptoCurrency/"));
     startActivity(intent);
    }

    public void openActivity3() {
        Intent intent2 = new Intent(this, Main3Activity.class);
                startActivity(intent2);
    }
}
