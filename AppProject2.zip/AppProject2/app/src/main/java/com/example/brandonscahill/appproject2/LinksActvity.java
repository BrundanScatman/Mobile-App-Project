package com.example.brandonscahill.appproject2;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LinksActvity extends AppCompatActivity {
    private Button btnBlock, btnTut, btnBooks, btnExc, btnCoin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_links_actvity);
        btnBlock = (Button) findViewById(R.id.button12);
        btnBlock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openBlockActivity();
            }
        });
        btnExc = (Button) findViewById(R.id.button11);
        btnExc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openExcActivity();
            }
        });
        btnTut = (Button) findViewById(R.id.button13);
        btnTut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTutActivity();
            }
        });
        btnCoin = (Button) findViewById(R.id.button14);
        btnCoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCoinActivity();
            }
        });
        btnBooks = (Button) findViewById(R.id.button15);
        btnBooks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openBookActivity();
            }
        });

    }
        public void openBlockActivity() {
            Intent intent1 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.blockchain.com"));
            startActivity(intent1);
        }

        public void openExcActivity() {
            Intent intent2 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.binance.com"));
            startActivity(intent2);
        }

    public void openTutActivity() {
        Intent intent3 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/datadash"));
        startActivity(intent3);
    }

    public void openCoinActivity() {
        Intent intent4 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.coinbase.com"));
        startActivity(intent4);
    }
    public void openBookActivity() {
        Intent intent5 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.audible.co.uk/search/ref=a_hp_tseft?advsearchKeywords=cryptocurrency&filterby=field-keywords"));
        startActivity(intent5);
    }

    }
