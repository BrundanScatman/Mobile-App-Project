package com.example.brandonscahill.appproject2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Coin_Info extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coin__info);

        Intent intent = getIntent();
        String currencyName = intent.getStringExtra(CryptoActivity.name);
        TextView title = findViewById(R.id.textView);
        title.setText(currencyName);
        String [] currencies = {"bitcoin", "ethereum", "ripple", "bitcoin cash", "litecoin",
                "eos", "cardano", "stellar", "neo", "iota"};
        Double [] HighestPrice = {19000.08, 1377.72, 3.65, 4091.70, 366.15, 18.16, 1.28, 0.85, 5.34, 162.11};
        Double [] LowestPrice = {68.08, 0.64, 0.004, 208.37, 2.12, 0.52, 0.02, 0.001590, 0.16, 0.08};
        String [] HighestDate = {"19/12/2017", "14/01/2018", "04/01/2018", "20/12/2017", "19/12/2017",
                "13/01/2018", "04/01/2018", "04/01/2018", "06/12/2017", "30/01/2018"};
        String [] LowestDate = {"07/07/2013", "10/08/2015", "09/08/2013", "06/08/2017", "15/01/2013",
                "28/10/2017", "06/10/2017", "28/10/2014", "16/07/2017", "22/10/2016"};
        String [] StartingDate = {"03/01/2009", "30/07/2015", "2012", "03/01/2009", "07/10/2011",
                "26/06/2017", "29/09/2017", "2014", "11/06/2016", "Feb 2014"};
        String [] devs = {"Satoshi Nakamoto", "Vitalki Buterin", "Jed McCaleb, Arthur Britto & David Schwartz",
                "ViaBTC", "Charlie Lee", "block.one", "Input Output Hong Kong (IOHK)", "Jed McCaleb & Joyce Kim",
                "David Sonstebo, Sergey Ivanchelgo, Dominik Schiener, & Sergei Popov", "Da Hongefei"};

        double highPrice = 0;
        double lowPrice = 0;
        String highDate = "";
        String lowDate = "";
        String startDate = "";
        String dev = "";

        for (int i = 0; i < 10; i++)    {
            if (currencyName.toLowerCase().equals(currencies[i]))   {
                highPrice = HighestPrice[i];
                lowPrice = LowestPrice[i];
                highDate = HighestDate[i];
                lowDate = LowestDate[i];
                startDate = StartingDate[i];
                dev = devs[i];
            }
        }

        String textset2 = "Highest Recorded Price:  " + highPrice + " on " + highDate;
        String textset3 = "Lowest Recorded Price:   " + lowPrice + " on " + lowDate;
        String textset4 = "Date created:    " + startDate;
        String textset5 = "Developer:    " + dev;

        TextView textView2 = findViewById(R.id.textView2);
        textView2.setText(textset2);

        TextView textView3 = findViewById(R.id.textView3);
        textView3.setText(textset3);

        TextView textView4 = findViewById(R.id.textView4);
        textView4.setText(textset4);

        TextView textView5 = findViewById(R.id.textView6);
        textView5.setText(textset5);
    }
}
